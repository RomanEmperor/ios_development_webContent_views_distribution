//
//  ViewController.swift
//  alertController
//
//  Created by Roman Emperor on 9/18/19.
//  Copyright © 2019 Roman Emperor. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    //MARK:- Outlets
    
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var sliderLabel: UILabel!
    
    @IBOutlet weak var progressView: UIProgressView!
    
    @IBOutlet weak var switchStatus: UILabel!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var waitingLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK:-  Actions [Button Functionality]
    
    // Alert Handler
    
    @IBAction func showAlert(_ sender: Any) {
        // defining alert
        let alert = UIAlertController(
        title: "Alert Title", message: "Alert Message", preferredStyle: .alert)
        
        // adding action to alert view
        
        let okayAction = UIAlertAction(
            title: "OK",
            style: .cancel) { (action) in
                print("OK Button was pressed")
        }
        alert.addAction(okayAction)
        
        let deleteAction = UIAlertAction(
            title: "Delete",
            style: .destructive) { (action) in
                print("Delete Button was pressed")
        }
        alert.addAction(deleteAction)
        
        
        // presenting alert
        present(
            alert,
            animated: true,
            completion: nil)
        
    }
    
    // Share Button Functionality
    
    @IBAction func shareBtn(_ sender: Any) {
        
        let activityVC = UIActivityViewController(
            activityItems: [textView.text],
            applicationActivities: nil)
        
        // presenting created activityVC to the user
        present(activityVC, animated: true, completion: nil)
        
    }
    
    // Slider Button Functionality
    
    @IBAction func sliderBtn(_ sender: UISlider) {
        sliderLabel.text = "\(sender.value)"
        
        // to move progressBar along with slider
//        progressView.setProgress(sender.value, animated: true)
    }
    
    // Toggle Switch Functionality
    
    @IBAction func toggleSwitch(_ sender: UISwitch) {
        switchStatus.text = sender.isOn ? "ON" : "OFF"
        if (sender.isOn){
            progressView.progress = 0
            waitingLabel.text = "Waiting"
            activityIndicator.startAnimating()
            
            Timer.scheduledTimer(
            withTimeInterval: 0.03,
            repeats: true){ (timer) in
                self.progressView.progress += 0.01
                if self.progressView.progress >= 1 {
                // stopping the timer
                timer.invalidate()
                self.activityIndicator.stopAnimating()
                    self.waitingLabel.text = "Done"
                }
            }
        }
    }
    
}

